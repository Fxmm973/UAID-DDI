# UAID-DDI — Implementation Audit & Submission Checklist

> **Manuscript:** "An Uncertainty-Aware Agent-Assisted Decision Framework for Rare Drug-Drug Interaction Prediction" (ERA, 2026)
>
> **Repository:** <https://github.com/Fxmm973/UAID-DDI>
>
> **Code snapshot:** `PharDDIE-mainyben （github）/`

---

## Target

- **Manuscript model names:** PharDDIE (few-shot, §2.4), EviDDIE (zero-shot, §2.5)
- **Evaluation benchmark:** Dataset 1 (DrugBank-derived, 1,706 drugs, 86 DDI event types)
- **Installation Tested on Ubuntu and windos 11 with Python 3.9 on one NVIDIA RTX 4090 GPU.
---

## Main Files

### PharDDIE (`PharDDIE/`) — Few-shot DDI prediction

| File | Purpose |
|:--|:--|
| `trainer_structure_acc_fp_neigh_VAE_struc.py` | **Training entry point.** Episodic meta-learning loop, `SigmoidLoss` metric classifier. VAE optimizer LR = base LR ×10. |
| `tester_struc_dataset1.py` | **Testing entry point.** Loops `few ∈ {1, 5, 10}` for Table 2 results. Loads `models_drugbank_{1,5,10}shot_str/bestmodel`. |
| `matcher_structure_acc_fp_neigh_VAE_struc.py` | **Core model.** `EmbedMatcher` class: `MVN_DDI` (CSE) → `neighbor_encoder` (ACI) → `VAE` → metric classifier `fc(64→128→64→1)`. |
| `layers.py` | `PharmacophoreAwareTransformerConv` (MME, Eq. 2.1–2.6), `MergeFD`, `CoAttentionLayer`, `RESCAL`. |
| `models_t_struc.py` | `MVN_DDI` GNN backbone (2 blocks × 2 heads, SAGPooling readout). |
| `modules_structure_fp_neigh.py` | Transformer attention library: `SupportEncoder`, `QueryEncoder` (LSTMCell), `MultiHeadAttention`. |
| `data_preprocessing_t.py` | RDKit molecular graph construction. Atom features 55-dim, bond features 17-dim. Morgan fingerprints 2048-dim. |
| `data_loader_structure_fp.py` | Episodic task sampler: `train_generate()` → support/query/false triples per event type. |
| `args.py` | Hyperparameters: `embed_dim=128`, `batch_size=256`, `lr=0.001`, `few=10`, `max_batches=10000`, `dropout=0.2`, `seed=19940419`. |
| `experiment_recorder.py` | Logs hyperparameters, training history, best models to `result_{prefix}.txt`. |
| `grapher.py` | Legacy KG path extraction (not used in the current pipeline). |

### EviDDIE (`EviDDIE/`) — Zero-shot DDI prediction

| File | Purpose |
|:--|:--|
| `trainer_structure_acc_fp_neigh_VAE_GAN_struc.py` | **Training entry point.** GAN stage (D/G alternating) + prototype alignment + `EvidentialLoss(annealing_step=10000)`. |
| `tester_structure_acc_fp_neigh_VAE_GAN_struc.py` | **Testing entry point.** Eval on dev/test splits. Uses generator `G_m` for task embeddings. |
| `eviddie_export_dataset1.py` | **Evaluation export script.** Per-sample predictions with EDL uncertainty (Dirichlet alpha). |
| `matcher_structure_acc_fp_neigh_VAE_GAN_struc.py` | **Core model.** `EmbedMatcher` with `Generate_Model` (G_φ), `Distinguish_Model` (C_ψ), `VAE`, `PrototypeAligner`, and EVI evidence head `fc(64→128→64→2)` + Softplus. |
| `models_t_struc.py` | `MVN_DDI` with plain `TransformerConv` + `PrototypeAligner` (BSA projection network G_φ). |
| `modules_structure_fp_neigh.py` | Transformer library (same as PharDDIE). |
| `data_preprocessing_t.py` | Molecular graph construction (same as PharDDIE). |
| `data_loader_structure_fp.py` | Task sampler — yields `task_name` for semantic embedding lookup. |
| `args.py` | Adds `--semantic event_embedding2.json`, `--proto_weight 2.0`, `max_batches=200000`. |
| `grapher.py` | Legacy KG path extraction (not used). |

---

## Naming Convention Map

Code identifiers that differ from manuscript terminology:

| Code name | Manuscript term | Explanation |
|:--|:--|:--|
| `VAE_GAN_struc` (EviDDIE filenames) | **EviDDIE** (overall) | "VAE" inherited from PharDDIE; "GAN" = adversarial critic in BSA (not image-generation GAN) |
| `Generate_Model` / `Distinguish_Model` | **G_φ** / **C_ψ** (BSA, §2.5.1) | Projection network and adversarial critic |
| `EviDTI` (code comments) | **EVI** (Evidence Variance Inference, §2.5.2) | DTI = Drug-Target Interaction, a prior project |
| `MVN_DDI` | **Chemical Structure Encoder (CSE)** | Inherited class name from prior multi-view work |
| `PharmacophoreAwareTransformerConv` | **MME** (Molecular Motif Extraction, §2.4.1) | Implements Eq. 2.1–2.6 |
| `AttentionSelectContext` / `neighbor_encoder` | **ACI** (Adaptive Context Integration, §2.4.2) | Implements Eq. 2.7–2.11 |

---

## Key Hyperparameters

| Param | PharDDIE | EviDDIE | Paper ref. |
|:--|:--|:--|:--|
| `embed_dim` | 128 | 128 | Drug embedding d |
| `batch_size` | 256 | 256 | Per episode |
| `lr` | 0.001 | 0.001 | Adam |
| `few` | 1 / 5 | 10 | K-shot setting |
| `max_batches` | 10,000 | 200,000 | Training iterations |
| `dropout` | 0.2 | 0.2 | — |
| Pharmacophore fusion λ | 0.3 | 0.3 | `0.7*gate + 0.3*pharm` |
| Pharmacophore amplification | 1.5 | 1.0 | Node weight scaling |
| `proto_weight` | — | 2.0 (args) | BSA alignment β |
| Evidential annealing | — | 10,000 steps | KL in `EvidentialLoss` |
| `seed` | 19940419 | 19940419 | Fixed |

---

## Quick Start

```bash
# Environment
conda env create -f environment.yml
conda activate PharDDIE

# PharDDIE — train 1-shot
cd PharDDIE
python trainer_structure_acc_fp_neigh_VAE_struc.py --dataset dataset1 --few 1 --prefix my_run

# PharDDIE — test 1/5/10-shot
python tester_struc_dataset1.py

# EviDDIE — train zero-shot
cd ../EviDDIE
python trainer_structure_acc_fp_neigh_VAE_GAN_struc.py --dataset dataset1 --prefix my_run

# EviDDIE — test + export uncertainty
python trainer_structure_acc_fp_neigh_VAE_GAN_struc.py --test --prefix my_run
python eviddie_export_dataset1.py --prefix my_run
```

---

## Data

Datasets are derived from DrugBank (license-restricted). Split indices, preprocessing scripts, random seeds, and semantic event embeddings are provided. Raw DrugBank records must be obtained from <https://go.drugbank.com/>.

---



