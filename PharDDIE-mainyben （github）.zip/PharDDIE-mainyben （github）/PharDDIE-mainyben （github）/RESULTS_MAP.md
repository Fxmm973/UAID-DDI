# RESULTS_MAP — Paper Tables to Reproduction Scripts

> **Manuscript:** "An Uncertainty-Aware Agent-Assisted Decision Framework for Rare Drug-Drug Interaction Prediction" (ERA, 2026)
>
> This file maps every result table and figure in the manuscript to the exact scripts and steps needed to reproduce them.

---

## Table 2 — Main Prediction Performance (Few-Shot & Rare-Event)

| Result | Script | How to Reproduce |
|:--|:--|:--|
| PharDDIE 1-shot (AUC/ACC/F1) | `PharDDIE/pharddie_test.py` | `python pharddie_test.py` — loops `few ∈ {1, 5, 10}`, reports per-setting metrics |
| PharDDIE 5-shot (AUC/ACC/F1) | `PharDDIE/pharddie_test.py` | Same script, 5-shot mode |
| RareDDIE | `PharDDIE/pharddie_train.py` | PharDDIE w/o MME (replace `PharmacophoreAwareTransformerConv` with plain `TransformerConv` in `layers.py`) |
| GMatching | Baseline repo | See original GMatching implementation (Xiong et al., EMNLP 2018) |
| MRCGNN | Baseline repo | See original MRCGNN implementation (Zhong et al., IEEE/ACM TCBB 2024) |
| MetaR-Pre / MetaR-In | Baseline repo | See original MetaR implementation (Chen et al., EMNLP 2019) |
| KnowDDI | Baseline repo | See original KnowDDI implementation (Xiong et al., AAAI 2023) |
| DSN-DDI | Baseline repo | See original DSN-DDI implementation (Li et al., Briefings in Bioinformatics 2023) |
| META-DDIE | Baseline repo | See original META-DDIE implementation (Deng et al., Briefings in Bioinformatics 2021) |

**Data splits:** Dataset 1 — `train_tasks.json` (58 events, 189,287 samples), `test_tasks.json` (13 fewer-events, 408 samples), `test2_tasks.json` (10 rare-events, 108 samples).

**Output:** Console log prints AUC/ACC/F1. Full report at `PharDDIE/result_{prefix}.txt`.

---

## Table 3 — Calibration Performance

| Result | Setting | How to Reproduce |
|:--|:--|:--|
| Softmax baseline | Zero-shot | Replace `EvidentialLoss` with `BCEWithLogitsLoss` in `EviDDIE/eviddie_train.py`, retrain with same seed |
| EviDDIE w/o EVI | Zero-shot | Set `--proto_weight 0` and remove `EvidentialLoss` (drops EVI, keeps BSA only) |
| EviDDIE (full) | Zero-shot | `python eviddie_train.py --dataset dataset1 --prefix eviddie_0shot` then `python eviddie_test.py` |
| PharDDIE | Rare-event | `python pharddie_test.py --few 5` on `test2_tasks.json` |
| PharDDIE + uncertainty head | Rare-event | Modify `pharddie_matcher.py`: replace `fc(64→128→64→1)` with `fc(64→128→64→2)` + Softplus, use `EvidentialLoss` |

**Calibration metrics (ECE, Brier, NLL, High-conf error) — post-processing from model outputs:**

```python
import numpy as np

def calibration_metrics(probs, labels, n_bins=10):
    """Compute all calibration metrics from (probability, label) pairs."""
    # ECE
    bin_boundaries = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    for i in range(n_bins):
        in_bin = (probs >= bin_boundaries[i]) & (probs < bin_boundaries[i+1])
        if in_bin.sum() > 0:
            ece += in_bin.sum() / len(probs) * abs(labels[in_bin].mean() - probs[in_bin].mean())

    # Brier score
    brier = np.mean((probs - labels) ** 2)

    # Negative log-likelihood
    eps = 1e-15
    nll = -np.mean(labels * np.log(probs + eps) + (1 - labels) * np.log(1 - probs + eps))

    # High-confidence error (predictions with p > 0.9)
    high_conf = probs > 0.9
    hc_error = 1.0 - labels[high_conf].mean() if high_conf.sum() > 0 else 0.0

    return {'ECE': ece, 'Brier': brier, 'NLL': nll, 'High_conf_error': hc_error}
```

Run `EviDDIE/eviddie_export.py` to get per-sample (probability, label) pairs, then apply the above.

---

## Table 4 — Agent-Assisted Prioritization

| Strategy | How to Reproduce |
|:--|:--|
| Random ranking | Baseline: shuffle candidate pairs randomly, compute P@K and selective risk |
| Probability only | Rank by predicted probability `p` from `eviddie_export.py` output |
| Probability + uncertainty | Rank by uncertainty-adjusted score `r = p × (1 − u)`; `u = 2 / (α₀ + α₁)` from Dirichlet alpha |

**Triage policy thresholds** (fixed on validation set `dev_tasks.json`):

| Condition | Action |
|:--|:--|
| p ≥ τₚ AND u < τᵤ | High-priority review |
| p ≥ τₚ AND u ≥ τᵤ | Expert referral |
| p < τₚ AND u ≥ τᵤ | Evidence request |
| Otherwise | Low-priority assignment |

**Metrics computation from (p, u, label) triples:**

```python
import numpy as np

def prioritization_metrics(probs, uncertainties, labels,
                           tau_p=0.5, tau_u=0.3):
    """Compute Table 4 metrics from per-sample outputs."""
    u = uncertainties  # epistemic uncertainty

    # Uncertainty-adjusted score
    r_adj = probs * (1.0 - u)

    # Triage assignments
    high_pri = (probs >= tau_p) & (u < tau_u)
    referral = (probs >= tau_p) & (u >= tau_u)

    # Coverage = fraction auto-processed (high-priority)
    coverage = high_pri.mean()

    # Referral rate
    referral_rate = referral.mean()

    # Selective risk = error rate among accepted (high-priority) predictions
    if high_pri.sum() > 0:
        selective_risk = 1.0 - labels[high_pri].mean()
    else:
        selective_risk = 0.0

    # Top-K precision (K = 10, 20, 50)
    def p_at_k(scores, k):
        idx = np.argsort(scores)[-k:]
        return labels[idx].mean()

    return {
        'P@10': p_at_k(r_adj, 10),
        'P@20': p_at_k(r_adj, 20),
        'P@50': p_at_k(r_adj, 50),
        'Referral_rate': referral_rate,
        'Coverage': coverage,
        'Selective_risk': selective_risk
    }
```

---

## Table 5 — Case Study (Top-10 Predicted DDIs)

**Procedure:**

1. Run EviDDIE inference on Dataset 2 candidate pairs:
   ```bash
   cd EviDDIE
   python eviddie_export.py --prefix eviddie_0shot --dataset dataset2
   ```

2. Rank all candidates by `r = p × (1 − u)` descending, select top 10.

3. Canonicalize drug identifiers to DrugBank IDs.

4. Screen pairs against `e1rel_e2.json` — **exclude any pair present in training records** to prevent data leakage.

5. For each of the top 10, annotate evidence status by cross-referencing DrugBank 5.0.

6. Report: Rank, Drug 1 (DrugBank ID), Drug 2 (DrugBank ID), Interaction description, Predicted probability, Evidence status (DrugBank-supported / Not identified).

**Note:** DrugBank evidence is used only for post-hoc plausibility checking, not for training or threshold selection. DrugBank-supported pairs are confirmatory (DrugBank is the benchmark source); unsupported pairs are routed to expert review.

---

## Supplementary Figures

| Figure | How to Reproduce |
|:--|:--|
| Fig. S1 (fusion weight λ) | In `PharDDIE/layers.py`, sweep `lam ∈ {0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0}` in `adaptive_weight = (1−lam)*gate + lam*pharm_boost`. Train PharDDIE 1-shot per λ, record validation metrics. |
| Figs. S2–S3 (PharDDIE ablation) | Train 3 variants: (1) w/o MME: replace `PharmacophoreAwareTransformerConv` with `TransformerConv`; (2) w/o ACI: comment out `neighbor_encoder`, use raw `MVN_DDI` output; (3) w/o VAE: replace VAE with direct MLP. Compare 1-shot and 5-shot results. |
| Fig. 2 (EviDDIE ablation) | Train 2 variants: (1) w/o BSA: `--proto_weight 0`, comment `Generate_Model`/`Distinguish_Model`; (2) w/o EVI: replace `EvidentialLoss` with `BCEWithLogitsLoss`. Plot AUROC/F1 vs. training iterations. |

---

## Data Availability Note

The following files are **provided in the repository** (public, no license restriction):

- `train_tasks.json`, `dev_tasks.json`, `test_tasks.json`, `test2_tasks.json` — split indices (DrugBank ID references)
- `event_embedding2.json` — precomputed BioSentVec event semantic embeddings (128-dim)
- `rel2candidates.json`, `e1rel_e2.json` — negative sampling and filtering dictionaries
- `DRKG_TransE_entity.npy`, `DRKG_TransE_relation.npy` — public DRKG embeddings
- `ent2ids`, `relation2ids`, `ent2embids`, `relation2embids` — ID mapping files

The following files require a **DrugBank academic license** and must be obtained from [https://go.drugbank.com/](https://go.drugbank.com/):

- `drug_smiles.csv` — SMILES strings for all drugs
- Raw DDI annotations used to construct `train_tasks.json` / `dev_tasks.json` / `test_tasks.json` / `test2_tasks.json`

Precomputed Morgan fingerprints (`morgan_dataset1.npz`) can be regenerated from SMILES using `PharDDIE/fp/save_features.py`.
