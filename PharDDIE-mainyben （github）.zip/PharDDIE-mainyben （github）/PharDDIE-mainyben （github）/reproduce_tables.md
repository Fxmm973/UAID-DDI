# Reproduce Tables — Step-by-Step Instructions

> **Manuscript:** "An Uncertainty-Aware Agent-Assisted Decision Framework for Rare Drug-Drug Interaction Prediction" (ERA, 2026)
>
> This document provides step-by-step instructions to reproduce Tables 2–5 and Supplementary Figures.

---

## Prerequisites

### 1. Environment

```bash
conda env create -f environment.yml
conda activate PharDDIE
```

### 2. Data Preparation

**Step 2a — Obtain DrugBank access.** Register for an academic license at [https://go.drugbank.com/](https://go.drugbank.com/). This is required to download SMILES strings and DDI annotation records.

**Step 2b — Download DRKG embeddings (public).** The DRKG TransE embeddings are available from the [DRKG repository](https://github.com/gnn4dr/DRKG):
- `DRKG_TransE_entity.npy`
- `DRKG_TransE_relation.npy`

**Step 2c — Prepare the dataset directory.** Create `dataset1/` under both `PharDDIE/` and `EviDDIE/` with the following files:

```
dataset1/
├── drug_smiles.csv          ← DrugBank SMILES (license required)
├── train_tasks.json         ← 58 training event types with samples
├── dev_tasks.json           ← 5 validation event types
├── test_tasks.json          ← 13 fewer-event test types
├── test2_tasks.json         ← 10 rare-event test types
├── rel2candidates.json      ← Candidate negative drugs per event
├── e1rel_e2.json            ← Known DDI dictionary
├── ent2ids                  ← Entity → integer ID mapping
├── relation2ids             ← Relation → integer ID mapping
├── ent2embids               ← Entity → DRKG row index
├── relation2embids          ← Relation → DRKG row index
├── path_graph               ← KG triples (entity \t relation \t entity)
├── DRKG_TransE_entity.npy   ← DRKG entity embeddings (public)
├── DRKG_TransE_relation.npy ← DRKG relation embeddings (public)
├── event_embedding2.json    ← BioSentVec 128-dim event vectors (EviDDIE only)
└── dti_entity.csv / dti_rel.csv  ← DTI mapping files
```

Plus precomputed fingerprints under `fp/features/`:
```
fp/features/
└── morgan_dataset1.npz      ← 2048-dim Morgan fingerprints
```

**Step 2d — Generate fingerprints (if not provided).**
```bash
cd PharDDIE/fp
python save_features.py
```

### 3. Verify Installation

```bash
# Quick syntax check — all .py files should compile
python -m py_compile PharDDIE/pharddie_train.py
python -m py_compile PharDDIE/pharddie_test.py
python -m py_compile EviDDIE/eviddie_train.py
python -m py_compile EviDDIE/eviddie_test.py
python -m py_compile EviDDIE/eviddie_export.py
```

---

## Table 2 — Few-Shot Prediction Performance

### PharDDIE (1-shot and 5-shot)

```bash
# Step 1: Train PharDDIE 1-shot
cd PharDDIE
python pharddie_train.py --dataset dataset1 --few 1 --prefix pharddie_1shot

# Step 2: Train PharDDIE 5-shot
python pharddie_train.py --dataset dataset1 --few 5 --prefix pharddie_5shot

# Step 3: Run batch evaluation (1/5/10-shot)
python pharddie_test.py
```

**Expected output:**
- Training metrics logged to `logs_/log-pharddie_1shot.txt` and `logs_/log-pharddie_5shot.txt`
- Experiment reports at `result_pharddie_1shot.txt` and `result_pharddie_5shot.txt`
- Test results printed to console with AUC, ACC, F1-score

**Baseline methods** (DSN-DDI, KnowDDI, MRCGNN, MetaR, GMatching, META-DDIE): Run each baseline's original implementation on the same dataset splits (`train_tasks.json` / `test_tasks.json` / `test2_tasks.json`). Baseline code is not included in this repository; refer to their respective publications.

---

## Table 3 — Calibration Performance

### EviDDIE (Zero-shot)

```bash
# Step 1: Train EviDDIE zero-shot
cd EviDDIE
python eviddie_train.py --dataset dataset1 --prefix eviddie_0shot

# Step 2: Test and export per-sample predictions
python eviddie_test.py
python eviddie_export.py --prefix eviddie_0shot
```

**Post-processing for calibration metrics:**

The `eviddie_export.py` script outputs per-sample files containing `(probability, uncertainty, alpha_0, alpha_1, true_label)`. Compute ECE, Brier score, NLL, and high-confidence error from these values:

```python
# Reference: calibration metric computation
import numpy as np

def compute_ece(probs, labels, n_bins=10):
    bins = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    for i in range(n_bins):
        mask = (probs >= bins[i]) & (probs < bins[i+1])
        if mask.sum() > 0:
            acc = labels[mask].mean()
            conf = probs[mask].mean()
            ece += mask.sum() / len(probs) * abs(acc - conf)
    return ece

def compute_brier(probs, labels):
    return np.mean((probs - labels) ** 2)

def compute_nll(probs, labels):
    eps = 1e-15
    return -np.mean(labels * np.log(probs + eps) + (1 - labels) * np.log(1 - probs + eps))

def compute_high_conf_error(probs, labels, threshold=0.9):
    mask = probs > threshold
    if mask.sum() == 0:
        return 0.0
    return 1.0 - labels[mask].mean()
```

### Softmax Baseline (for Table 3 comparison)

Modify `EviDDIE/eviddie_train.py`:
1. Replace `EvidentialLoss` with `torch.nn.BCEWithLogitsLoss()`
2. Replace the evidence head `fc(64→128→64→2)` with `fc(64→128→64→1)` + Sigmoid
3. Retrain with the same data and seeds

### PharDDIE + Uncertainty Head (rare-event setting, Table 3 bottom)

Modify `PharDDIE/pharddie_matcher.py`:
1. Replace `fc(64→128→64→1)` with `fc(64→128→64→2)` + Softplus (as in EviDDIE)
2. Replace `SigmoidLoss` with `EvidentialLoss`
3. Retrain on Dataset 1 and test on rare-event split

---

## Table 4 — Agent-Assisted Prioritization

All results in Table 4 are computed from the **same EviDDIE model outputs** as Table 3.

```bash
# Export per-sample (p, u) pairs
cd EviDDIE
python eviddie_export.py --prefix eviddie_0shot
```

**Post-processing for triage metrics:**

```python
# Reference: triage policy and prioritization metrics
import numpy as np

def compute_uncertainty(alpha):
    """Epistemic uncertainty from Dirichlet distribution"""
    return 2.0 / alpha.sum(axis=1)  # K=2

def triage(p, u, tau_p=0.5, tau_u=0.3):
    """Rule-based triage policy (Section 2.8)"""
    if p >= tau_p and u < tau_u:
        return 'high_priority'
    elif p >= tau_p and u >= tau_u:
        return 'expert_referral'
    elif p < tau_p and u >= tau_u:
        return 'evidence_request'
    else:
        return 'low_priority'

def top_k_precision(scores, labels, k):
    idx = np.argsort(scores)[-k:]
    return labels[idx].mean()

def selective_risk(scores, labels, coverage):
    """Risk among top-coverage fraction"""
    n = int(len(scores) * coverage)
    idx = np.argsort(scores)[-n:]
    return 1.0 - labels[idx].mean()

# Probability-only ranking
r_prob = p

# Uncertainty-adjusted ranking (Eq. in Section 2.8)
r_adj = p * (1.0 - u)
```

**Note:** Thresholds τₚ and τᵤ must be tuned on the **validation set** (`dev_tasks.json`) and fixed before computing held-out metrics. The paper uses validation-based threshold selection.

---

## Table 5 — Case Study (Top-10 Predictions)

### Step 1: Run EviDDIE on Dataset 2 candidate pairs

```bash
cd EviDDIE
python eviddie_export.py --prefix eviddie_0shot --dataset dataset2
```

### Step 2: Rank and annotate

1. Rank all candidate pairs by uncertainty-adjusted score `r = p * (1 - u)` descending
2. Take the top 10 pairs
3. Canonicalize drug identifiers to DrugBank IDs (DBXXXXX format)
4. Screen against `e1rel_e2.json` to exclude pairs present in training
5. Cross-reference each pair against DrugBank 5.0 for evidence annotation
6. Report: Rank, Drug 1, Drug 2, Description, Probability, Evidence status

**Important:** DrugBank evidence annotation is **post-hoc plausibility checking**, not independent discovery. Since DrugBank is also the benchmark source, annotated pairs are confirmatory rather than novel findings.

---

## Supplementary Figures

### Fig. S1 — Fusion Weight λ Analysis

Manually vary the pharmacophore fusion coefficient in `PharDDIE/layers.py`:

```python
# In PharmacophoreAwareTransformerConv.forward(), line ~158:
# Default: adaptive_weight = 0.7 * gate + 0.3 * pharm_boost
# Sweep: try λ ∈ {0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0}
adaptive_weight = (1 - lam) * gate + lam * pharm_boost
```

Train PharDDIE 1-shot with each λ and record validation AUC/ACC/F1.

### Figs. S2–S3 — PharDDIE Ablation

| Variant | Modification in `pharddie_matcher.py` |
|:--|:--|
| w/o MME | Replace `PharmacophoreAwareTransformerConv` with plain `TransformerConv` |
| w/o ACI | Comment out `neighbor_encoder`, use only `MVN_DDI` output |
| w/o VAE | Replace VAE latent encoding with direct concatenation + MLP |

Train each variant with 1-shot and 5-shot settings, keeping all other hyperparameters fixed.

### Fig. 2 — EviDDIE Ablation

| Variant | Modification |
|:--|:--|
| w/o BSA | In `eviddie_train.py`, set `--proto_weight 0` and comment out `Generate_Model`/`Distinguish_Model` |
| w/o EVI | Replace `EvidentialLoss` with `BCEWithLogitsLoss` and evidence head with Sigmoid |
| Full EviDDIE | Default configuration |

Train each variant in zero-shot mode and plot AUROC/F1 vs. training iterations.

---

## Expected Runtime

| Experiment | Hardware | Approximate Time |
|:--|:--|:--|
| PharDDIE 1-shot training | RTX 4090 | ~2 hours (10,000 batches) |
| PharDDIE 5-shot training | RTX 4090 | ~2 hours |
| EviDDIE zero-shot training | RTX 4090 | ~8 hours (200,000 batches) |
| PharDDIE test (1/5/10-shot loop) | RTX 4090 | ~30 minutes |
| EviDDIE test + export | RTX 4090 | ~1 hour |

---

## Troubleshooting

| Issue | Solution |
|:--|:--|
| `FileNotFoundError: dataset1/drug_smiles.csv` | DrugBank license required — see Prerequisites Step 2a |
| `FileNotFoundError: DRKG_TransE_entity.npy` | Download from [DRKG repository](https://github.com/gnn4dr/DRKG) |
| `CUDA out of memory` | Reduce `--batch_size` from 256 to 128 or 64 |
| PharDDIE forced CPU mode | Edit `pharddie_train.py` line 47: change `self.device = 'cpu'` to `self.device = 'cuda'` |
| Import errors after renaming | Run `python -m py_compile *.py` in each directory to verify imports |
| `event_embedding2.json` not found (EviDDIE) | Precomputed from BioSentVec; reconstruction script available upon request |
