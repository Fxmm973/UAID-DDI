# UAID-DDI — Implementation Audit & Submission Checklist

> **Manuscript:** "An Uncertainty-Aware Agent-Assisted Decision Framework for Rare Drug-Drug Interaction Prediction" (ERA, 2026)
>
> **Repository:** <https://github.com/Fxmm973/UAID-DDI>

---

## Target

- **Manuscript model names:** PharDDIE (few-shot, §2.4), EviDDIE (zero-shot, §2.5)
- **Evaluation benchmark:** Dataset 1 — DrugBank-derived: 1,706 drugs, 86 DDI event types
- **Installation:** Tested on Ubuntu 22.04 and Windows 11, Python 3.9, one NVIDIA RTX 4090 GPU

---

## Main Files

### PharDDIE (`PharDDIE/`) — Few-shot DDI prediction (§2.4)

| File | Purpose |
|:--|:--|
| `pharddie_train.py` | **Training entry point.** Episodic meta-learning loop, `SigmoidLoss` metric classifier, VAE optimizer LR = base LR ×10. |
| `pharddie_test.py` | **Testing entry point.** Loops `few ∈ {1, 5, 10}` for Table 2 results. |
| `pharddie_matcher.py` | **Core model.** `EmbedMatcher` class: CSE (`MVN_DDI`) → ACI (`neighbor_encoder`, `AttentionSelectContext`) → `VAE` → metric classifier `fc(64→128→64→1)`. |
| `molecular_encoder.py` | `MVN_DDI` GNN backbone: 2 blocks × 2 heads, `PharmacophoreAwareTransformerConv`, SAGPooling readout. |
| `layers.py` | `PharmacophoreAwareTransformerConv` (MME, Eq. 2.1–2.6), `MergeFD`, `CoAttentionLayer`, `RESCAL`. |
| `meta_modules.py` | Transformer attention library: `SupportEncoder`, `QueryEncoder` (LSTMCell), `MultiHeadAttention`. |
| `data_preprocessing.py` | RDKit molecular graph construction: atom features 55-dim, bond features 17-dim, Morgan fingerprints 2048-dim. |
| `data_loader.py` | Episodic task sampler: `train_generate()` → support/query/false triples per event type. |
| `args.py` | Hyperparameters: `embed_dim=128`, `batch_size=256`, `lr=0.001`, `few=10`, `max_batches=10000`, `dropout=0.2`, `seed=19940419`. |
| `experiment_recorder.py` | Logs hyperparameters, training history, best models to `result_{prefix}.txt`. |
| `grapher.py` | Legacy KG path extraction (not used in current pipeline). |

### EviDDIE (`EviDDIE/`) — Zero-shot DDI prediction (§2.5)

| File | Purpose |
|:--|:--|
| `eviddie_train.py` | **Training entry point.** GAN stage (G_φ/C_ψ alternating) + prototype alignment + `EvidentialLoss(annealing_step=10000)`. |
| `eviddie_test.py` | **Testing entry point.** Eval on dev/test splits. Uses generator for task embeddings. |
| `eviddie_export.py` | **Evaluation export.** Per-sample predictions with EDL uncertainty (Dirichlet alpha, u = K/Σα). |
| `eviddie_matcher.py` | **Core model.** `EmbedMatcher` with `Generate_Model` (G_φ), `Distinguish_Model` (C_ψ), `VAE`, `PrototypeAligner`, and EVI evidence head `fc(64→128→64→2)` + Softplus. |
| `molecular_encoder.py` | `MVN_DDI` with plain `TransformerConv` + `PrototypeAligner` (BSA projection network G_φ). |
| `meta_modules.py` | Transformer library (same as PharDDIE). |
| `data_preprocessing.py` | Molecular graph construction (same as PharDDIE). |
| `data_loader.py` | Task sampler — yields `task_name` for semantic embedding lookup. |
| `args.py` | Adds `--semantic event_embedding2.json`, `--proto_weight 2.0`, `max_batches=200000`. |
| `grapher.py` | Legacy KG path extraction (not used). |

---

## Internal Naming: Class-Level Identifiers vs. Manuscript

File names now match the manuscript. Within the code, a few class names still use development-era identifiers:

| Code class/identifier | Manuscript term | Location |
|:--|:--|:--|
| `Generate_Model` / `G_m` | **G_φ** — BSA projection network (§2.5.1) | `eviddie_matcher.py`, `eviddie_train.py` |
| `Distinguish_Model` / `D_m` | **C_ψ** — BSA adversarial critic (§2.5.1) | `eviddie_matcher.py`, `eviddie_train.py` |
| `EviDTI` (comments) | **EVI** — Evidence Variance Inference (§2.5.2) | `eviddie_matcher.py`, `eviddie_train.py` |
| `PharmacophoreAwareTransformerConv` | **MME** — Molecular Motif Extraction (§2.4.1) | `layers.py` |
| `AttentionSelectContext` / `neighbor_encoder` | **ACI** — Adaptive Context Integration (§2.4.2) | `pharddie_matcher.py` |
| `VAE` (class) | **VAE** — Variational Autoencoder (§2.4.3) | Both matchers |
| `PrototypeAligner` | **G_φ** — Semantic-to-prototype mapper (§2.5.1) | EviDDIE `molecular_encoder.py` |
| `EvidentialLoss` | **EVI** — Dirichlet evidential objective (§2.5.2) | `eviddie_train.py` |

---

## Module → File Quick Reference

| Manuscript Module | Primary File | Key Lines |
|:--|:--|:--|
| **MME** (pharmacophore encoding) | `PharDDIE/layers.py` | `PharmacophoreAwareTransformerConv.forward()` — fusion λ=0.3, amplification ×1.5 |
| **MME** (GNN backbone) | `PharDDIE/molecular_encoder.py` | `MVN_DDI.forward()` |
| **ACI** (KG context) | `PharDDIE/pharddie_matcher.py` | `neighbor_encoder()`, `AttentionSelectContext.forward()` |
| **VAE** (latent space) | `PharDDIE/pharddie_matcher.py` | `VAE.encode()`, `VAE.sampling()`, `VAE.decode()` |
| **BSA** (semantic alignment) | `EviDDIE/eviddie_matcher.py` | `Generate_Model`, `Distinguish_Model`, `PrototypeAligner` |
| **BSA** (adversarial training) | `EviDDIE/eviddie_train.py` | `train_standard()` — G/D alternating + proto loss + var loss |
| **EVI** (evidence head) | `EviDDIE/eviddie_matcher.py` | `EmbedMatcher.forward()` — `F.softplus(fc(...))`, `alpha = evidence + 1` |
| **EVI** (evidential loss) | `EviDDIE/eviddie_train.py` | `EvidentialLoss(annealing_step=10000)` |
| **Meta-learning** | Both `data_loader.py` | `train_generate()` — episodic support/query sampling |

---

## Key Hyperparameters

| Param | PharDDIE | EviDDIE | Paper ref. |
|:--|:--|:--|:--|
| `embed_dim` | 128 | 128 | Drug embedding d |
| `batch_size` | 256 | 256 | Per episode |
| `lr` | 0.001 | 0.001 | Adam |
| `few` | 1 / 5 | 10 | K-shot setting |
| `max_batches` | 10,000 | 200,000 | Training iterations |
| `dropout` | 0.2 | 0.2 | — |
| Pharmacophore fusion λ | 0.3 | 0.3 | `0.7*gate + 0.3*pharm` |
| Pharmacophore amplification | 1.5 | 1.0 | Node weight scaling |
| `proto_weight` | — | 2.0 (args) | BSA alignment β |
| Evidential annealing | — | 10,000 steps | KL in `EvidentialLoss` |
| `seed` | 19940419 | 19940419 | Fixed |

---

## Quick Start

```bash
# Environment
conda env create -f environment.yml
conda activate PharDDIE

# PharDDIE — train 1-shot
cd PharDDIE
python pharddie_train.py --dataset dataset1 --few 1 --prefix my_run

# PharDDIE — test 1/5/10-shot
python pharddie_test.py

# EviDDIE — train zero-shot
cd ../EviDDIE
python eviddie_train.py --dataset dataset1 --prefix my_run

# EviDDIE — test + export uncertainty
python eviddie_test.py
python eviddie_export.py --prefix my_run
```

---


